public class usaCalculadora {
    public static void main(String[] args) {
        @SuppressWarnings("unused")
        calculadora calc = new calculadora();
    }

}
