package itz;

public class Lista {
    protected Nodo inicio,fin;//punteros para saber donde esta el inicio y el fin de la lista 
  
    public Lista(){
        inicio = null;
        fin = null;
    }
    //metodo para agregar un nodo al inicio de la lista
    public void agregarAlInicio(int elemento){
        inicio = new Nodo(elemento, inicio);
        if(fin == null){
            fin = inicio;
        }
    }
    //metodo para mostrar los datos
    public void mostrarLista(){
        Nodo recorrer = inicio;
        System.out.println();
        while(recorrer != null){
            System.out.print("["+recorrer.dato+"]-->");
            recorrer = recorrer.siguiente;
        }
    }    
    
}
