package itz;

public class Principal {
    public static void main(String[] args) {
        int opcion = 0,el;
        Lista listita = new Lista();
        do{
            try{
                opcion = Integer.parseInt(javax.swing.JOptionPane.showInputDialog(null,
                        "1. Agregar al inicio\n"
                        + "2. Mostrar lista\n"
                        + "3. Salir\n"
                        + "¿Que deseas hacer?", "Menu de opciones", 3));

                switch(opcion){
                    case 1:
                        try{
                            el = Integer.parseInt(javax.swing.JOptionPane.showInputDialog(null, "Ingresa el elemento", "Agregando al inicio", 3));

                            listita.agregarAlInicio(el);
                        }catch(NumberFormatException n){
                            javax.swing.JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
                        }
                    break;
                    case 2:
                    try{
                        listita.mostrarLista();
                    }catch(Exception e){
                        javax.swing.JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
                    }

                    break;
                    case 3:
                        javax.swing.JOptionPane.showMessageDialog(null, "Aplicacion finalizada", "Fin", 1);
                       System.exit(0);
                        break;
                    default:
                        javax.swing.JOptionPane.showMessageDialog(null, "Opcion incorrecta", "Error", 0);
                }
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
            }
        }while(opcion != 3);
    }

}
