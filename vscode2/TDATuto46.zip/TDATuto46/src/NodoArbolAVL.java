public class NodoArbolAVL {

    int dato,fe;
    NodoArbolAVL hijoizquierdo,hijoDerecho;

    public NodoArbolAVL(int d){
        this.dato = d;
        this.fe = 0;
        this.hijoizquierdo = null;
        this.hijoDerecho = null;
    }
    
        

}
