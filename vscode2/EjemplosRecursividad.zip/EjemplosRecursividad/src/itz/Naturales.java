package itz;

public class Naturales {
    public static void main(String[] args) {
        
    }
    public static int sumaRecursiva(int entero){
        if()
    }

}
