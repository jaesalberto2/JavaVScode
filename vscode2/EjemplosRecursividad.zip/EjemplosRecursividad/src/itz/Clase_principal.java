package itz;

public class Clase_principal {
    public static void main(String[] args) {
        Recursividad recu = new Recursividad();
        recu.Imprimir(1);
    }

}
