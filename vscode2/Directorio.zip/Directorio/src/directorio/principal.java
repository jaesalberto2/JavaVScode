package directorio;

public class principal {

}
