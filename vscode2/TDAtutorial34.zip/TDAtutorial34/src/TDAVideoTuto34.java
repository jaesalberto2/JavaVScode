import javax.swing.JOptionPane;
public class TDAVideoTuto34 {

    public static void main(String[] args) {
        int opcion = 0, elemento;
        String nombre;
        ArbolBinario arbolito = new ArbolBinario();


        do{
            try{
               opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                       "1. Agregar un nodo\n"
                       + "2. Salir\n"
                       + "Elige una opcion...", "Arboles Binarios",
                       JOptionPane.QUESTION_MESSAGE));
                switch(opcion){
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el numero del nodo", "Agregando Nodo",
                                JOptionPane.QUESTION_MESSAGE));
                        nombre = JOptionPane.showInputDialog(null,
                                "Ingresa el nombre del nodo", "Agregando Nodo",
                                JOptionPane.QUESTION_MESSAGE);
                        arbolito.agregarNodo(elemento, nombre);
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, "Aplicacion finalizada",
                                "Fin", JOptionPane.INFORMATION_MESSAGE);
                                System.exit(0);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opcion incorrecta",
                                "Error", JOptionPane.INFORMATION_MESSAGE);
                }

            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
            }
        }while(opcion != 2);
    }
}
